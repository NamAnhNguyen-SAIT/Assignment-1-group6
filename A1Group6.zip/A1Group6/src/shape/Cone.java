package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class Cone extends Shape{

	/**
	 * declare radius
	 */
	private double radius;
	
	/**
	 * 
	 * @param radius
	 * @param height
	 */
	public Cone(double radius, double height) {
		super(height);
		this.radius = radius;
	}

	/**
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * @param radius set radius
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	/**
	 * calculate base area of cone
	 * @return base area
	 */
	@Override
	public double calcBaseArea() {
		return Math.PI * getRadius()*getRadius();
	}
	
	/**
	 * calculate volume of cone
	 * @return volume
	 */
	@Override 
	public double calcVolume() {
		return  1 / 3 * calcBaseArea() * getHeight();
	}
	
}
