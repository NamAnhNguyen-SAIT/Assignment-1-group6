
package shape;

/**
 * 
 * @author Yuxiao Shen
 *
 */
public abstract class Prism extends Shape{
	private double side;
	
	public Prism(double height, double side) {
		super(height);
		this.side = side;
	}

	/**
	 * @return get side
	 */
	public double getSide() {
		return side;
	}

	/**
	 * @param side set side
	 */
	public void setSide(double side) {
		this.side = side;
	}

	/**
	 * calculate base area of prism
	 * @return base area of prism
	 */
	@Override
	public double calcBaseArea() {
		return side;
		
	}

	/**
	 * calculate volume of prism
	 * @return volume of prism
	 */
	@Override
	public double calcVolume() {
		return calcBaseArea()*getHeight();
	}
	
}
