package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class OctagonPrism extends Prism{

	/**
	 * 
	 * @param height
	 * @param side
	 */
	public OctagonPrism(double height, double side) {
		super(height, side);
	}

	/**
	 * calculate base area of Octagon Prism
	 * @return base area of Octagon Prism
	 */
	@Override
	public double calcBaseArea() {

		return 2 * (1 + Math.sqrt(3)) * Math.pow(getSide(), 2.0);
	}

	/**
	 * calculate volume of Octagon Prism
	 * @return volume of Octagon Prism
	 */
	@Override
	public double calcVolume() {
		return calcBaseArea() * getHeight();
	}
	
}
