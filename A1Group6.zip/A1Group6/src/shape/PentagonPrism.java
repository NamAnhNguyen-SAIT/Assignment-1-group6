package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class PentagonPrism extends Prism{

	/**
	 * 
	 * @param height
	 * @param side
	 */
	public PentagonPrism(double height, double side) {
		super(height, side);
	}

	/**
	 * calculate base area of Pentagon Prism
	 * @return base area of Pentagon Prism
	 */
	@Override 
	public double calcBaseArea() {
		return 5 * getSide() * getSide() * Math.tan(54) / 4;
	}
	
	/**
	 * calculate volume of Pentagon Prism
	 * @return volume of Pentagon Prism
	 */
	@Override
	public double calcVolume() {
		return calcBaseArea() * getHeight();
	}
}
