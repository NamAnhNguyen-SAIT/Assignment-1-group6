package shape;

/**
 * @author Yuxiao Shen
 *
 */

public class Cylinder extends Shape{
	/**
	 * declare radius
	 */
	private double radius; 
	
	/**
	 * 
	 * @param height
	 * @param radius
	 */
	public Cylinder(double height, double radius) {
		super(height);
		this.radius = radius; 
	}
	
	/**
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * @param set radius
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	/**
	 * calculate base area of cylinder
	 * @return base area of cylinder
	 */
	@Override
	public double calcBaseArea() {
		return Math.PI * getRadius()*getRadius();
	}
	
	/**
	 * calculate volume of cylinder
	 * @return volume of cylinder
	 */
	@Override
	public double calcVolume() {
		return calcBaseArea() * getHeight();
	}

}
