package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class SquarePrism extends Prism{
	
	/**
	 * 
	 * @param height
	 * @param side
	 */
	public SquarePrism(double height, double side) {
		super(height, side);
	}
	
	/**
	 * calculate base area of Square Prism
	 * @return base area of Square Prism
	 */
	@Override
	public double calcBaseArea(){
		return getSide()*getSide();
	}
	
	/**
	 * calculate volume of Square Prism
	 * @return volume of Square Prism
	 */
	@Override
	public double calcVolume() {
		return calcBaseArea() * getHeight();
	}
}
