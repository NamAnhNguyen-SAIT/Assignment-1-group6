package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class Pyramid extends Shape{

	/**
	 * declare side
	 */
	private double side;
	
	/**
	 * 
	 * @param height
	 * @param side
	 */
	public Pyramid(double height, double side) {
		super(height);
		this.side = side;
	}

	/**
	 * calculate base area of pyramid
	 * @return base area of pyramid
	 */
	@Override
	public double calcBaseArea() {
		return side * side;
	}

	/**
	 * calculate volume of pyramid
	 * @return volume of pyramid
	 */
	@Override
	public double calcVolume() {
		return side * getHeight();
	}

}
