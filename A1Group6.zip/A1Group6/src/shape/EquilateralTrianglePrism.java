package shape;
/**
 * 
 * @author Yuxiao Shen
 *
 */
public class EquilateralTrianglePrism extends Prism{

	/**
	 * 
	 * @param height
	 * @param side
	 */
	public EquilateralTrianglePrism(double height, double side) {
		super(height, side);
	}

	/**
	 * calculate base area of Equilateral Triangle Prism
	 * @return base area of Equilateral Triangle Prism
	 */
	@Override
	public double calcBaseArea() {
		return Math.pow(getSide(), 2.0) * Math.sqrt(3) / 4;
	}
	
	/**
	 * calculate volume of Equilateral Triangle Prism
	 * @return volume of Equilateral Triangle Prism
	 */
	@Override
	public double calcVolume() {
		return this.calcBaseArea() * super.getHeight();
	}
}
