package shape;

/**
 * 
 * @author Yuxiao Shen
 *
 */

public abstract class Shape implements Comparable<Shape>{
	
	/**
	 * declare height
	 */
	private double height;
	
	public Shape(double height) {
		this.height = height;
	}

	/**
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * @param set the height
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	
	/**
	 * 
	 */
	@Override 
	public int compareTo(Shape that) {
		
		if (this.height < that.height) {
			return -1;
		}
		if (this.height > that.height) {
			return 1;
		}
		return 0;
	}
	
	/**
	 * 
	 * @return
	 */
	public abstract double calcBaseArea();
	
	/**
	 * 
	 * @return
	 */
	public abstract double calcVolume();

	
	
}
